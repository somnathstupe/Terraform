import json

def lambda_handler(event, context):
    # TODO implement
    print("This from seconnd function",event)
    return event
