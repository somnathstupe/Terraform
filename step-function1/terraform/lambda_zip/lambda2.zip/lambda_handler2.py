
def lambda_handler(event, context):
    # TODO implement
    print(event)
    return event
